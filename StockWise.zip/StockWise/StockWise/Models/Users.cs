﻿using Microsoft.AspNetCore.Identity;
namespace StockWise.Models
{
    public class Users : IdentityUser
    {
        public String FUllName { get; set; }
    }



}