﻿using System.ComponentModel.DataAnnotations;

namespace StockWise.viewModels
{
    public class VerifyEmail
    {
        [Required(ErrorMessage = " Email is Required")]
        [EmailAddress]
        public string Email { get; set; }
    }
}
