﻿using System.ComponentModel.DataAnnotations;

namespace StockWise.viewModels
{
    public class ChangePasswordViewModel
    {
        public  string? Name { get; set; }

        [Required(ErrorMessage = " Email is Required")]
        [EmailAddress]
        public  string? Email { get; set; }

        [Required(ErrorMessage = " NewPassword is Required")]
        [StringLength(40, MinimumLength = 8, ErrorMessage = " The {0} must be at {2} and  at max {1} character")]
        [DataType(DataType.Password)]
        [Compare("ConfirmNewPassword", ErrorMessage = " NewPassword does not match ")]
        public  string? NewPassword { get; set; }

        [Required(ErrorMessage = " Confirm NewPassword  is Required")]
     
        [DataType(DataType.Password)]
        //[Display( Name ="Confirm New Password ")]
        public   string? ConfirmNewPassword { get; set; }
    }
}
