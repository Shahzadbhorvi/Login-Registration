﻿using System.ComponentModel.DataAnnotations;
namespace StockWise.viewModels
  
{
    public class LoginViewModel
    {
        [Required (ErrorMessage = " Email is required")]
        [EmailAddress]
        public  string Email { get; set; }
        [DataType (DataType.Password)]
        [Required (ErrorMessage ="PASSWORD IS REQUIRED")] public string Password { get; set; }
        
       [Display (Name = "Remember Me?")]public bool RememberMe { get; set; }
    }
}
